package org.code.aurora.wallpapersandstyles;

import android.os.Bundle;
import android.preference.SwitchPreference;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import org.code.aurora.wallpapersandstyles.databinding.ActivityStatusBinding;

public class StatusActivity extends AppCompatActivity {
    public ActivityStatusBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityStatusBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v ->{
            onBackPressed();
        });
        	getSupportFragmentManager().beginTransaction().replace(R.id.settings_container,new SettingsPreference()).commit();
    }
}
