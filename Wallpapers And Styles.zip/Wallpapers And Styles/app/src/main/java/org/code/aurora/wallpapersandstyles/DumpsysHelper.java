package org.code.aurora.wallpapersandstyles;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class DumpsysHelper {

    public static String runDumpsysCommand(String serviceName) {
        StringBuilder output = new StringBuilder();
        try {
            Process process = Runtime.getRuntime().exec("dumpsys " + serviceName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            process.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return output.toString();
    }
}