package org.code.aurora.wallpapersandstyles;
import android.app.Application;
import com.google.android.material.color.DynamicColors;
import com.google.android.material.color.utilities.DynamicColor;

public class AppName extends Application{
    @Override
    public void onCreate() {
        super.onCreate();
        DynamicColors.applyToActivitiesIfAvailable(this);
    }
}
